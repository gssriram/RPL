from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

# Create your views here.

def home(request):
    return(render(request, 'home.html', {}))

def chatbot(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request,user)
            messages.success(request, 'Log In Successfull !!!')
            return redirect('chatbot')
        else:
            messages.success(request, 'Either Username or Password is incorrect. Please try again...')
            return redirect('chatbot')

    else:
        return(render(request, 'chatbot.html', {}))

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request,user)
            messages.success(request, 'Log In Successfull !!!')
            return redirect('home')
        else:
            messages.success(request, 'Either Username or Password is incorrect. Please try again...')
            return redirect('home')
    else:
        return(render(request, 'user_login.html', {}))

def user_logout(request):
    logout(request)
    messages.success(request, "You've been logged out successfully !!!")
    return redirect('home')